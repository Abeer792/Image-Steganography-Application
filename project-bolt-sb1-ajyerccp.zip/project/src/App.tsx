import React, { useState, useRef } from 'react';
import { Upload, Download, Lock, Image as ImageIcon } from 'lucide-react';

function App() {
  const [message, setMessage] = useState('');
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [decodedMessage, setDecodedMessage] = useState('');
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const hideData = (imageData: ImageData, message: string) => {
    const data = imageData.data;
    const messageBytes = new TextEncoder().encode(message);
    const messageBits = [];
    
    // Convert message to bits
    for (let i = 0; i < messageBytes.length; i++) {
      for (let j = 7; j >= 0; j--) {
        messageBits.push((messageBytes[i] >> j) & 1);
      }
    }
    
    // Add message length as header (16 bits)
    const lengthBits = [];
    for (let i = 15; i >= 0; i--) {
      lengthBits.push((messageBytes.length >> i) & 1);
    }
    
    const allBits = [...lengthBits, ...messageBits];
    
    // Hide bits in LSB of RGB components
    for (let i = 0; i < allBits.length; i++) {
      const pixelIndex = i * 4;
      data[pixelIndex] = (data[pixelIndex] & 0xFE) | allBits[i];
    }
    
    return imageData;
  };

  const extractData = (imageData: ImageData) => {
    const data = imageData.data;
    const lengthBits = [];
    
    // Extract length bits
    for (let i = 0; i < 16; i++) {
      lengthBits.push(data[i * 4] & 1);
    }
    
    // Calculate message length
    let messageLength = 0;
    for (let i = 0; i < 16; i++) {
      messageLength = (messageLength << 1) | lengthBits[i];
    }
    
    // Extract message bits
    const messageBits = [];
    for (let i = 16; i < 16 + messageLength * 8; i++) {
      messageBits.push(data[i * 4] & 1);
    }
    
    // Convert bits to bytes
    const messageBytes = new Uint8Array(messageLength);
    for (let i = 0; i < messageLength; i++) {
      let byte = 0;
      for (let j = 0; j < 8; j++) {
        byte = (byte << 1) | messageBits[i * 8 + j];
      }
      messageBytes[i] = byte;
    }
    
    return new TextDecoder().decode(messageBytes);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setSelectedImage(event.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleEncode = () => {
    if (!selectedImage || !message || !canvasRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const img = new Image();
    img.onload = () => {
      canvas.width = img.width;
      canvas.height = img.height;
      ctx.drawImage(img, 0, 0);
      
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const encodedImageData = hideData(imageData, message);
      ctx.putImageData(encodedImageData, 0, 0);
      
      // Download encoded image
      const link = document.createElement('a');
      link.download = 'encoded-image.png';
      link.href = canvas.toDataURL();
      link.click();
    };
    img.src = selectedImage;
  };

  const handleDecode = () => {
    if (!selectedImage || !canvasRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const img = new Image();
    img.onload = () => {
      canvas.width = img.width;
      canvas.height = img.height;
      ctx.drawImage(img, 0, 0);
      
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const decoded = extractData(imageData);
      setDecodedMessage(decoded);
    };
    img.src = selectedImage;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-gray-800 text-white p-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-4xl font-bold text-center mb-8">
          Image Steganography
        </h1>
        
        <div className="bg-gray-800 rounded-lg p-6 shadow-xl mb-8">
          <div className="flex flex-col items-center gap-6">
            <div className="w-full">
              <label className="block text-sm font-medium mb-2">Upload Image</label>
              <div className="flex items-center justify-center w-full">
                <label className="w-full flex flex-col items-center justify-center h-64 border-2 border-gray-600 border-dashed rounded-lg cursor-pointer hover:bg-gray-700 transition-colors">
                  <div className="flex flex-col items-center justify-center pt-5 pb-6">
                    <ImageIcon className="w-12 h-12 mb-4 text-gray-400" />
                    <p className="mb-2 text-sm text-gray-400">
                      <span className="font-semibold">Click to upload</span> or drag and drop
                    </p>
                  </div>
                  <input
                    type="file"
                    className="hidden"
                    accept="image/*"
                    onChange={handleImageUpload}
                  />
                </label>
              </div>
            </div>

            {selectedImage && (
              <div className="w-full">
                <img
                  src={selectedImage}
                  alt="Selected"
                  className="max-w-full h-auto rounded-lg"
                />
              </div>
            )}

            <div className="w-full">
              <label className="block text-sm font-medium mb-2">Secret Message</label>
              <textarea
                className="w-full px-3 py-2 bg-gray-700 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                rows={4}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Enter your secret message here..."
              />
            </div>

            <div className="flex gap-4">
              <button
                onClick={handleEncode}
                className="flex items-center gap-2 px-6 py-3 bg-blue-600 rounded-lg hover:bg-blue-700 transition-colors"
              >
                <Upload className="w-5 h-5" />
                Encode Message
              </button>
              <button
                onClick={handleDecode}
                className="flex items-center gap-2 px-6 py-3 bg-green-600 rounded-lg hover:bg-green-700 transition-colors"
              >
                <Download className="w-5 h-5" />
                Decode Message
              </button>
            </div>

            {decodedMessage && (
              <div className="w-full">
                <h3 className="text-lg font-medium mb-2 flex items-center gap-2">
                  <Lock className="w-5 h-5" />
                  Decoded Message
                </h3>
                <div className="p-4 bg-gray-700 rounded-lg">
                  <p className="break-words">{decodedMessage}</p>
                </div>
              </div>
            )}
          </div>
        </div>

        <canvas ref={canvasRef} className="hidden" />
      </div>
    </div>
  );
}

export default App;